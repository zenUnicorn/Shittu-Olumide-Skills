# Voice examples

Short excerpts from Shittu's articles, grouped by pattern. Excerpts from the earlier era (2022–23) show his own voice and are the main model for how sentences should sound. Excerpts from the recent era (2026) are included for structural ideas only. Use these to calibrate tone, not to copy phrasing word for word.

## Openings that ground the topic (earlier, his own voice)

> If you often go online to read articles and blogs, you've probably noticed or come across a section under the article you just finished reading with a heading "Suggested articles" or "Similar articles." This is done with a recommender algorithm.

> The funny thing about programming is that bugs can often be a real headache.

> Recently I was working with Comet, and I was trying to log my visualizations to the platform... If you are experiencing this, then let us walk through the issue together and solve this error.

> Do you want to quickly log your data and visualize it in Comet with the new built-in data panel tool? If yes, you are in the right place.

## Framing fact and named project (recent, structure to borrow)

The idea worth keeping: tell the reader early what the tool really is and what we'll build. Say it plainly.

Recent phrasing (too dramatic):
> Here's the fact worth knowing before anything else about this topic: OGX is the rebrand of Meta's Llama Stack.

Blended phrasing:
> If you've read about Llama Stack before, you already know more about OGX than you think. OGX is the new name for Meta's Llama Stack, and most of what's been written about Llama Stack still applies.

> In this article, we will build an app (let's call it DocBrain) that does two things.

## Announcing what we'll cover (earlier)

> In this article, we will cover everything you need to know to get started with keyword extraction using the Python programming language, such as the benefits of keyword extraction, who it is beneficial for, significant Python libraries, and lastly, how to extract keywords in real-time.

> You will learn about automated forecasting, AutoTS, and some of its features. We will close this article by working on a dataset and using the AutoTS package to perform automated time series forecasting.

## Defining before using (earlier)

> Before delving into keyword extraction, we must first define what a keyword is.

> A named entity is a real-world object that has a unique identifier and can be identified by a proper name.

## Transitions and asides (earlier)

> Let's have a look at the matrix, shall we?

> With this being settled, let's get our hands dirty by building a model which will be able to predict the given language.

> Luckily for us, scikit-learn has an inbuilt TfidfVectorizer that generates the TF-IDF matrix.

> Moving on, we will make use of Term Frequency-Inverse Document Frequency (TF-IDF) vectors...

> I personally use Comet with Python, but you can also use Comet with R and Java.

## Explaining code (blend)

Earlier style, good voice but only says *what*:
> In the code above, we created an empty list text_list for appending the preprocessed text, we then iterate through all the text (X), removed the symbols and numbers, converted the text to lowercase, and finally append it to the list.

Recent style, says *why* but sounds AI-written:
> Storing entries as JSON Lines (one JSON object per line, appended) rather than one large JSON array is a deliberate, practical choice: appending a line is trivial and safe even if the process is interrupted mid-write, while appending to a JSON array correctly requires reading, modifying, and rewriting the whole file every time.

Blend (target):
> In the code above, we save each action item as its own line in a JSON Lines file. We chose this over a regular JSON array because adding an item just means appending one line. With a JSON array, we would have to read, update, and rewrite the whole file every time, and a crash halfway through could corrupt it.

## Notes and tips (earlier)

> Note: It is important that you have a stable internet connection when deploying to Comet, in order to avoid running into errors.

> Tip: If you aren't sure what a specific named entity abbreviation stands for, you can easily check it with the explain() method.

## Conclusions (blend)

Earlier:
> With this, we have come to the end of the article. We've learned what named entity recognition is, its applications, how to implement NER using spaCy, and some of the top NER APIs... Be sure to check out my GitHub repo for the full code used in this article.

Recent (too sloganeering):
> That's the real difference between an API wrapper and an actual agentic platform, and it's the reason this project is worth building on rather than throwing away the moment it needs to grow up.

Blend (target):
> We have come to the end of this article. We looked at what OGX is, set up a local server with Ollama, and built DocBrain, an assistant that answers questions from your documents and saves action items to a file. The nice part is that when you're ready to move to production, you only need to change the model and provider settings; the rest of the code stays the same. You can find the full code in my GitHub repo [link]. I hope you enjoyed building this with me!

## Trimming AI tells: before and after

Before:
> If it finds a genuine deadline or task while answering, check action_items.jsonl afterward — a real, saved record will be sitting there, not just text that scrolled past in a terminal.

After:
> If it finds a deadline or task while answering, check action_items.jsonl afterward. You should see the saved item there.

Before:
> The real contribution here isn't a new way to prompt a model; plenty of tools already do that well. It's treating an agent's definition as a portable, versionable artifact.

After:
> What I like most about Docker Agent is that an agent becomes something you can version and share, just like a container image.
