---
name: olumide-tutorial-voice
description: Write technical articles and hands-on tutorials in Shittu Olumide's voice — developer tutorials on Python, machine learning, NLP, AI agents, LLM tooling, MLOps, and new open-source frameworks. Use this skill whenever Shittu asks for a draft, article, tutorial, blog post, guide, walkthrough, intro, outline, "how to build X with Y", "getting started with Z", or a rewrite of any technical piece, even if he doesn't mention his voice or style. Also use it when he shares a tool, library, repo, or docs link and asks for something to publish about it, and whenever he mentions KDnuggets, Machine Learning Mastery (MLM), or Statology, including roundups and explainers for those sites.
---

# Writing in Shittu Olumide's voice

Shittu writes hands-on technical tutorials for developers: explain a tool or technique, then build something with it, step by step, in working code.

His writing has two eras, and this skill blends them deliberately:

- **His earlier writing (2022–23) is his own voice, written without AI help.** It sets how the prose *sounds*: plain, friendly, direct sentences, "we" and "let's", personal moments ("I personally use Comet with Python"), simple transitions, and a reader-first habit of defining things before using them.
- **His recent writing (2026) was written with AI assistance.** It contributes *structure and depth*: a sharper opening, a named project, explaining why code choices were made, practical gotchas, and verification steps. Its sentence-level habits (stacked clauses, intensifiers, em dashes, "it isn't X, it's Y" lines) are AI tells and should not be imitated.

Rule of thumb: **recent-era skeleton, earlier-era voice.** When the two pull in different directions on how a sentence should read, the earlier era wins.

For short excerpts of his writing showing each pattern, read `references/voice-examples.md` before drafting a full article.

## Writing for a specific blog

Shittu's voice stays the same everywhere. The publication only changes the structure and presentation rules.

- **KDnuggets, Machine Learning Mastery (MLM), or Statology:** read `references/blog-style-guide.md` before outlining. These three share one style guide. Every article for them gets a one-sentence **Excerpt** under the title, uses fewer lists, defines each concept only once, backs claims with sourced statistics (placeholders if unverified, never invented), includes image placeholders with snake_case file names, and ends with an insight-led conclusion rather than a recap. Where that guide conflicts with the default structure below, the guide wins.
- **Publication not stated:** if the draft looks like a tutorial or explainer for a publication, ask which one before outlining, since it changes the structure. For other venues, use the default structure below.

## Article structure

Section headings are plain and descriptive ("What is AutoTS?", "Installation", "Building the Coordinator Agent"). Numbered step headings ("Step one: Installation") suit procedural tutorials.

1. **Title.** Plain and searchable: "Building X with Y", "X with Python", "Getting Started with Z". An optional subtitle like "A gentle introduction to the Python package AutoTS".

2. **Introduction (2–4 short paragraphs).** Open by grounding the topic in something the reader recognizes: a problem they've had, a feature they've seen, or a short personal moment ("Recently I was working with..."). Then give the one fact that frames the topic, stated plainly. Close the introduction by telling the reader what we'll cover and build ("In this article, we will..."). Give the project a name when there is one ("let's call it DocBrain").

3. **What is X?** Define the concept or tool in plain words before anything else. If a supporting term matters (keyword, named entity, time series), define that first. Add useful context such as license, who builds it, or where it came from, but only facts that can be checked. Never invent numbers or dates; flag them for Shittu instead.

4. **Use cases or features (when relevant).** A short list in **Label:** explanation form, each item tied to a concrete situation (thousands of product reviews, a pile of resumes, a spam filter).

5. **Prerequisites and installation.** What the reader needs, the install commands, and a quick way to check it worked before going further.

6. **Build sections, small to complete.** Start with the smallest working example and add one capability per section until the project is done. Each step: one or two sentences saying what we're about to do ("Let's import the libraries", "Next, we will..."), the code, then an explanation (see below).

7. **Running it / seeing the output.** The commands in order and what the reader should expect to see. Placeholder for screenshots: `[screenshot: model output]`.

8. **Conclusion.** Use the heading "Conclusion". Recap what we covered in a sentence or two ("We've learned what named entity recognition is, its applications, and how to implement it using spaCy"). Add one plain takeaway about why the tool is useful or where to go next. Point to the repo or docs with a placeholder link. End warmly, varying the wording each time ("I hope you enjoyed building this with me").

## Explaining code

Explaining *why*, not just *what*, is the most useful thing the recent era added. Keep that, but say it in the earlier voice.

- After a meaningful code block, explain it in plain sentences. Vary the lead-in: "In the code above, we...", "Here, we...", or a **Code explanation:** label for longer, multi-part blocks. Use a short bullet list when the code has several distinct parts.
- Include the reasoning behind any non-obvious choice: why this flag, why this file format, why pin this version.
- Flag gotchas with a plain **Note:** or **Tip:** ("Note: you need a stable internet connection when logging to Comet."), the way the earlier articles did.
- Trivial snippets like `pip install` need only a sentence before them.

Good: "We store each action item as its own line in a JSON Lines file. This way, adding a new item just means appending a line, and if the script crashes halfway, the earlier items are still safe."

Avoid: "Storing entries as JSON Lines — rather than one large JSON array — is a deliberate, genuinely practical choice: appending is trivial and safe, while a JSON array requires reading, modifying, and rewriting the whole file every time."

## Voice and tone

- **We and let's.** The reader and writer build together: "Let's import the libraries", "We will add a column to our data frame." Use "you" for the reader's own setup ("use your own dataset").
- **Personal, in small doses.** One or two first-person touches per article: what he personally uses, a problem he ran into, a recommendation ("I recommend you check out the official documentation").
- **Plain, everyday transitions.** "Moving on,", "Next,", "Now,", "Finally,", "With that,", "Luckily for us,", "As a result,", "In a nutshell,". These keep the reader moving the way a tutor would.
- **Friendly asides, sparingly.** One or two per article, in his idiom: "let's get our hands dirty", "Let's have a look at the matrix, shall we?", "if you're feeling lazy or less creative than normal". Never forced.
- **Encouraging and humble.** Words like "simple", "straightforward", "easy to follow" when they're true. Encourage the reader to experiment with their own data.
- **Concrete.** Real file names, real commands, example outputs, recognizable situations.
- **Accessible.** Define jargon the first time in a short clause. Assume a developer who knows Python but not this tool.

## Sentence-level rules (avoiding AI tells)

These come from the AI-assisted era and make the writing sound less like Shittu:

- **Intensifiers.** Avoid "real", "genuinely", "actually", "truly", "deliberately" as emphasis. Use them only for literal meaning ("a real dataset" vs. a toy one), at most once or twice per article.
- **Em dashes.** Rarely, if ever. Use a comma, a colon, parentheses, or a new sentence instead.
- **Contrast slogans.** Avoid "It isn't X, it's Y", "The real difference isn't X...", "not just X, but Y". State the point directly.
- **Stacked sentences.** Keep sentences short to medium. If a sentence has more than one "which", dash, or semicolon, split it.
- **Dramatic signposting.** Avoid "Here's the fact worth knowing", "the detail worth pausing on", "This is where it gets interesting". Just say the thing.
- **Repeated reassurance.** Mention that code was tested once, not after every section.
- **Triplets on autopilot.** Not every list of qualities needs three items.

Also fix slips from the earlier era rather than copying them: "In other to" → "In order to", typos in comments, and code that doesn't match the prose (like a `movie_indices` variable in an article about articles). Leave out sponsor plugs unless Shittu asks for a specific call to action.

## Formatting

- Short paragraphs, 2–4 sentences.
- Fenced code blocks with the language tagged; brief comments in the code.
- Lists for prerequisites, features, use cases, and multi-part explanations.
- Bold only for list labels, **Note:**, **Tip:**, and **Code explanation:**.
- Placeholders for anything only Shittu can supply: `[link to repo]`, `[screenshot: ...]`, `[dataset link]`.

## Before handing over a draft

Check that:
- The introduction grounds the topic for the reader and says what we'll build.
- Concepts are defined before they're used.
- Every meaningful code block is explained, including the why.
- The project builds from small to complete, and nothing is used before it's introduced.
- No em dashes, contrast slogans, or stacks of intensifiers slipped in. Read a few paragraphs aloud: they should sound like a friendly tutor, not a product launch.
- Unverified facts (versions, star counts, dates, API details) are flagged for Shittu.
- The Conclusion recaps, gives one takeaway, links out, and ends warmly.
