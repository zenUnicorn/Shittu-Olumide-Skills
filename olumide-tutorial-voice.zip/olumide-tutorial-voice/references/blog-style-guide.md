# Style guide: KDnuggets, Machine Learning Mastery (MLM), and Statology

These three blogs share one style guide. When an article is for any of them, write in Shittu's voice (SKILL.md) and use this guide to shape the article. The voice never changes; this guide decides structure, density, and presentation. Where this guide conflicts with the default structure in SKILL.md, this guide wins.

## Always: the Excerpt

Every article gets an excerpt: one short sentence placed directly under the title. It appears below the title in category views and search results, so it should tell a reader what they'll get and make them want to click. Keep it concrete and plain. Don't restate the title word for word.

Format:

    # Building AI Applications with OGX
    **Excerpt:** Learn how to build a local, OpenAI-compatible AI app that answers questions from your documents and saves action items, using OGX and Ollama.

## The standard: better than AI output

The editor accepts AI assistance but expects the final article to be far better than what a model gives in one or two prompts. In practice, that means:

- **Depth over general explanation.** Go past the definition. Add real-world applications, worked examples, specific numbers, and the practical detail someone only knows from using the tool.
- **No repetition.** Define each concept once. If the introduction defines the topic, the "What is X?" section must go deeper instead of restating it. Don't re-explain points later in the article.
- **Something the competing articles lack.** Before outlining, think about what the top two or three existing articles on the topic cover, and what they miss or explain poorly. Build the article around filling that gap. If Shittu hasn't said what the angle is, propose one at the top of the draft.
- **SEO-aware.** Detailed enough to rank. Use the main keyword naturally in the title, excerpt, introduction, and at least one heading. Headings should be descriptive phrases a reader might search for.

## Clear, natural writing

- Short sentences. If a sentence feels clunky, split it.
- Simple words over jargon. When a technical term is needed, explain it in plain words the first time.
- Active voice. "Experts believe AI will change the world," not "It is believed by experts..."
- Show, don't just define. Explain a concept through how it works in a real situation.

## Introductions

- Capture attention in the first two or three sentences with an interesting fact, a bold statement, or a relatable situation.
- Never open with generic filler such as "In today's fast-paced world..." or "Technology is evolving rapidly."
- Shittu's own example of a strong opening:
  > If you work with data for a living, 2025 has probably felt different. Privacy used to be something your legal team handled in a long PDF nobody reads.

## Conclusions

For these blogs, the conclusion should **not** be a recap of everything the article said. The heading can be "Conclusion" or "Wrapping Up". Keep it short and give the reader something fresh, using one or more of:

- A final insight, takeaway, or prediction
- A "what's next" pointer (what to build or learn next, links to docs or the repo)
- Shittu's own opinion or advice

A single sentence of recap is fine as a bridge, but the weight should be on the new thought. Shittu's own example:

> If you take anything from these five stories, let it be this: data privacy is no longer something handed off to legal or compliance. It's embedded in the work analysts do every day. Version your inputs. Label your data. Trace your transformations.

A warm one-line send-off is still welcome, as long as it isn't the whole conclusion.

## Lists: use less, write more

The editor sees heavy bullet use as an AI habit. Default to flowing paragraphs, and use a list only when it clearly helps the reader: install steps, a practical checklist, or items the reader will scan or follow in order.

Instead of:
> Here are the benefits of AI:
> - It's efficient.
> - It reduces costs.
> - It automates tasks.

Write:
> AI makes processes more efficient by reducing costs and automating repetitive tasks. This means businesses can focus on higher-value work instead of manual processes.

This applies to use cases and features too. The **Label:** list format from SKILL.md should become short paragraphs for these blogs unless there are many parallel items. Multi-part code explanations can still use a short list.

## Data, statistics, and links

- Back up claims about trends, popularity, or growth with a statistic and a named source. "AI adoption has grown by 75% in the last five years (Source: XYZ Report)" beats "AI is growing rapidly."
- Link to the official documentation whenever a library, tool, or framework is mentioned, at least the first time.
- **Never invent statistics, sources, or links.** If a claim needs a number Shittu hasn't supplied and that can't be verified, write a placeholder like `[STAT NEEDED: share of companies using X, with source]` or `[LINK: official docs]`. Unflagged made-up numbers would damage his credibility with the editor.

## Visuals

Every article should include images, charts, diagrams, or screenshots where they clarify something (architecture, a workflow, model output, a chart of results). In the draft, mark each one with a placeholder that includes a proper file name in snake_case or kebab-case and a one-line description:

    [IMAGE: docker_agent_team_architecture.png — diagram of the coordinator delegating to the researcher and writer agents]

Suggest at least two or three visuals per article.

## Submission notes (for Shittu, not the article)

Images go in a Google Drive folder (with editor access shared on the folder and the doc) or are sent by email, named in snake_case or kebab-case, e.g. `ai_market_analysis_chart.png`. At the end of a draft, list the image placeholders together so he can prepare and name the files.

## Article formats these blogs publish

Shittu writes two kinds of pieces here:

**Hands-on tutorials** (most common): follow the structure in SKILL.md, adjusted by the rules above (excerpt, fewer lists, no repeated definitions, insight-led conclusion).

**Roundups and explainers** (e.g. "5 Data Privacy Stories from 2025 Every Analyst Should Know"):
- A relatable, attention-grabbing opening that names who the article is for, then one paragraph saying what we'll look at and why it matters ("These aren't abstract trends... They're real events that changed how analysts work day to day").
- One heading per item, written as a clear statement of what happened ("Data Lineage Enforcement Went Mainstream").
- In each item: what happened (with dates, numbers, and sources), then why it matters to the reader, then what they should do. Short question-style subheadings work well here ("Why Analysts Should Care", "What Should Analysts Do?"), without question marks after non-questions.
- Practical advice tied to the reader's real tools (Python, R, SQL, Excel, BI dashboards).
- A conclusion that pulls the items into one takeaway rather than summarizing each one.
